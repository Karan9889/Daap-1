'use strict';

export const police = {
  theftClaims: null
};

