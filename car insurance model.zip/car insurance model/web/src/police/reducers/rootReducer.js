'use strict';

import { combineReducers } from 'redux';

import police from './policeReducer';

export default combineReducers({ police });
