'use strict';

export const shop = {
  type: undefined,
  products: [],
  productInfo: undefined
};

export const insurance = {
  contractTypes: undefined,
  contractInfo: undefined
};

export const payment = {
  payed: false
};

export const userMgmt = {
  new: true,
  user: undefined
};
