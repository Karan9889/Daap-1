'use strict';

export const COMPLETE_PAYMENT = 'COMPLETE_PAYMENT';
