# Daap-1
Project : Car Insurance 

Group Members:
Karanjot Singh - 101195883
Anushka Aggarwal - 101195651

In this project, Blockchain Technology is implemented in an insurance arena for collection of claims. This program is executed on IBM Blockchain Platform.

For Execution, run the following :
1. docker-images.sh
2. build_ubuntu.sh
3. generate-certs.sh
4. generate-cfgtx.sh
5. docker-compose -f docker-compose.yaml up -d
